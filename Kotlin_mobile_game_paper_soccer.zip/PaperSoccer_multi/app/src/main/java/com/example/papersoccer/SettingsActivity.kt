package com.example.papersoccer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.Toast

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val sound = findViewById<Switch>(R.id.soundSwitch)
        val vibrations = findViewById<Switch>(R.id.vibrationsSwitch)
        val back = findViewById<Button>(R.id.backButton)
        var soundIsOn : Boolean= true
        var vibrationsAreOn : Boolean = true

        //switches on
        sound.isChecked = true
        vibrations.isChecked = true

        //switch listeners

        sound.setOnCheckedChangeListener {
                buttonView, isChecked ->

                if(isChecked){

                    Toast.makeText(this, "Sound on", Toast.LENGTH_SHORT).show()
                    soundIsOn = true

                }

                else{

                    Toast.makeText(this, "Sound off", Toast.LENGTH_SHORT).show()
                    soundIsOn = false

                }

        }

        vibrations.setOnCheckedChangeListener {
                buttonView, isChecked ->
                if(isChecked){

                    Toast.makeText(this, "Vibrations on", Toast.LENGTH_SHORT).show()
                    vibrationsAreOn = true

                }

                else{

                    Toast.makeText(this, "Vibrations off", Toast.LENGTH_SHORT).show()
                    vibrationsAreOn = false

                }


        }

        back.setOnClickListener{

            finish()

        }
    }
}