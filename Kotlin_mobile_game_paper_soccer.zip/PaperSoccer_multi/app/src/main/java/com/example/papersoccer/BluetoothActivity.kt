package com.example.papersoccer

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class BluetoothActivity : AppCompatActivity() {

    //? allows the adapter to be nullable, therefore bluetooth availability may be checked
    private var bluetoothAdapter : BluetoothAdapter? = null
    private lateinit var pairedDevices : Set<BluetoothDevice>
    private val requestEnableBluetooth = 1
    //private val listView = findViewById<ListView>(R.id.list_view)

    //purposes of global usage
    companion object{

        val extraAddress : String = "DeviceAddress"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth)

        val listView = findViewById<ListView>(R.id.list_view)

        val refresh = findViewById<Button>(R.id.refresh)

        val back = findViewById<Button>(R.id.goBack)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            val permissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            ActivityCompat.requestPermissions(this, permissions, 0)
        }

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        if(bluetoothAdapter == null){

            Toast.makeText(this, "Bluetooth is not supported on this device", Toast.LENGTH_SHORT).show()
            refresh.isEnabled = false

        }

        //add location
        else if(!bluetoothAdapter!!.isEnabled){

            val enableBluetoothIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBluetoothIntent, requestEnableBluetooth)

        }


        refresh.setOnClickListener{

            //assigns all the discoverable devices to pairedDevices
            pairedDevices = bluetoothAdapter!!.bondedDevices
            val list : ArrayList<BluetoothDevice> = ArrayList()

            if(!pairedDevices.isEmpty()){

                for(device: BluetoothDevice in pairedDevices){

                    list.add(device)
                    Log.i("device", ""+device)

                }

            }

            else{

                Toast.makeText(this, "No discoverable devices have been found", Toast.LENGTH_SHORT).show()

            }

            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
            listView.adapter = adapter

            listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
                val device: BluetoothDevice = list[position]
                val address: String = device.address

                val intent = Intent(this, MultiActivity::class.java)
                intent.putExtra(extraAddress, address)
                startActivity(intent)
            }

        }

        back.setOnClickListener {

            finish()

        }


}

    //cases of the bluetooth actually being disabled, let's the user know if the bluetooth has been successfully enabled
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == requestEnableBluetooth){

            if(resultCode == Activity.RESULT_OK){

                if(bluetoothAdapter!!.isEnabled){

                    Toast.makeText(this, "Bluetooth has been enabled", Toast.LENGTH_SHORT).show()

                }
                else{

                    Toast.makeText(this, "Bluetooth has been disabled", Toast.LENGTH_SHORT).show()

                }
            }

            else if(resultCode == Activity.RESULT_CANCELED){

                Toast.makeText(this, "Bluetooth enabling operation has been cancelled", Toast.LENGTH_SHORT).show()
            }

        }
    }
}
