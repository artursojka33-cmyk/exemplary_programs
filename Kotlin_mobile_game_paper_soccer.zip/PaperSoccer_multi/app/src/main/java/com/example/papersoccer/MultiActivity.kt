package com.example.papersoccer

import android.app.ProgressDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import java.io.IOException
import java.util.*

class MultiActivity : AppCompatActivity() {
    companion object{

        var mUUID : UUID = UUID.fromString("5de86152-6cd4-4749-8e80-81b26bd75f1f")
        var bluetoothSocket : BluetoothSocket? = null
        lateinit var progress : ProgressDialog
        lateinit var bluetoothAdapter : BluetoothAdapter
        var isConnected : Boolean = false
        lateinit var mAddress : String
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multi)

        mAddress = intent.getStringExtra(BluetoothActivity.extraAddress).toString()

        MultiActivity.ConnectToDevice(this).execute()

        val quit = findViewById<Button>(R.id.quitButton2)

        quit.setOnClickListener {

            if(bluetoothSocket != null){

                try{

                    bluetoothSocket!!.close()
                    bluetoothSocket = null
                    isConnected = false

                }

                catch(e: IOException){
                    e.printStackTrace()

                }

            }

            finish()

        }
    }

    private class ConnectToDevice(c: Context) : AsyncTask<Void, Void, String>(){

        private var connectSuccess : Boolean = true
        private val context: Context

        init{

            this.context = c

        }

        override fun onPreExecute() {
            super.onPreExecute()
            progress = ProgressDialog.show(context, "Connecting...", "it will take a few moments")
        }

        override fun doInBackground(vararg params: Void?): String? {
            try{

                if(bluetoothSocket == null || !isConnected){

                    bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    val device : BluetoothDevice = bluetoothAdapter.getRemoteDevice(mAddress)
                    bluetoothSocket = device.createInsecureRfcommSocketToServiceRecord(mUUID)
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                    bluetoothSocket!!.connect()

                }

            }

            catch(e: IOException){
                connectSuccess = false
                e.printStackTrace()

            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if(!connectSuccess){

                Log.i("data", "couldn't connect")
            }
            else{

                isConnected = true

            }
            progress.dismiss()
        }

    }
}