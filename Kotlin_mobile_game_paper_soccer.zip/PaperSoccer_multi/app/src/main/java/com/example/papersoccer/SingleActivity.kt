package com.example.papersoccer

import android.annotation.SuppressLint
import android.content.res.Resources
import android.graphics.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.ImageView
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.widget.TextView
import android.widget.Toast


var currentHeight : Int = 0
var currentWidth: Int = 0
var check = false

class SingleActivity : AppCompatActivity() {
    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_single)

        val quit = findViewById<Button>(R.id.quitButton)
        val imageView: ImageView = findViewById(R.id.imageView)
        val width = Resources.getSystem().displayMetrics.widthPixels
        val height = Resources.getSystem().displayMetrics.heightPixels
        val reset = findViewById<Button>(R.id.resetButton)

        lateinit var mRunnable:Runnable
        lateinit var mHandler: Handler

        val widthOfTheField = width - 220
        val heightOfTheField = height - 800
        val bitmap = Bitmap.createBitmap(widthOfTheField, heightOfTheField, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.rgb(153,201,0))
        val paint = Paint()

        var previousHeight = heightOfTheField/2
        var previousWidth = widthOfTheField/2
        var was_red = false
        var diffHeight : Int = 0
        var diffWidth : Int = 0
        var edgeCheck : Boolean = false
        var leftCheck : Boolean = false
        var rightCheck : Boolean = false
        var upCheck : Boolean = false
        var downCheck : Boolean = false
        var movePermission : Boolean = false
        var checkNextWidth : Boolean = false

        val previousHeightList = mutableListOf<Int>()
        val previousWidthList = mutableListOf<Int>()

        var currentIndex : Int = -1
        var wannaReset : Int = 0

        var samePreviousHeight: Boolean = false
        var samePreviousWidth: Boolean = false
        var spotAlreadyTaken: Boolean = false

        var counterRed: Int= 0
        var counterBlue: Int =0

        val redText = findViewById<TextView>(R.id.redText)
        val blueText = findViewById<TextView>(R.id.blueText)

        paint.color = Color.rgb(215,224,210)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 18F
        paint.isAntiAlias = true

        paintCourt(canvas, heightOfTheField, widthOfTheField, paint)

        val canvasv2 = Canvas(bitmap)
        canvasv2.drawARGB(0,0,0,0)
        val paintv2 = Paint()
        paintv2.color = Color.rgb(100,100,100)
        paintv2.strokeWidth = 16F
        paintv2.style = Paint.Style.STROKE
        paintv2.isAntiAlias = true
        paintv2.isDither = true

        paintDots(canvasv2, heightOfTheField, widthOfTheField, paintv2)

        val canvas3 = Canvas(bitmap)
        canvas3.drawARGB(0,0,0,0)
        val paint3 = Paint()
        //pastel red
        paint3.color = Color.rgb(170,35,35)
        paint3.strokeWidth = 16F
        paint3.style = Paint.Style.STROKE
        paint3.isAntiAlias = true
        paint3.isDither = true

        canvas3.drawCircle(widthOfTheField/2.toFloat(), heightOfTheField/2.toFloat(), 5F, paint3)
        was_red = true

        currentHeight = 0
        currentWidth = 0
        check = false
        reset.isEnabled = false
        mHandler = Handler()

        mRunnable = Runnable {
            if(check) {

                val pointHeight = (currentHeight-575)/97
                val pointWidth = (currentWidth-105)/114

                println("Current Height ")
                println(pointHeight)
                println("Current Width ")
                println(pointWidth)

                previousHeightList.forEach{

                    if(!samePreviousHeight){
                            currentIndex += 1
                        if (it == pointHeight) {
                            samePreviousHeight = true
                            checkNextWidth = true
                            println("List Height ")
                            println(it)

                        }

                    }

                    if(checkNextWidth){

                        if (previousWidthList[currentIndex] == pointWidth) {

                            samePreviousWidth = true
                            println("List Width ")
                            println(previousWidthList[currentIndex])

                        }

                        else{

                            samePreviousHeight = false

                        }

                        checkNextWidth = false


                    }


                }

                if (samePreviousHeight && samePreviousWidth) {

                    spotAlreadyTaken = true
                    samePreviousHeight = false
                    samePreviousWidth = false
                    currentIndex = -1


                } else {

                    samePreviousHeight = false
                    samePreviousWidth = false
                    currentIndex = -1

                }


                diffHeight = currentHeight - previousHeight - 575
                diffWidth = currentWidth - previousWidth - 105

                if (currentHeight - 545 >= 0 && currentHeight - 605 <= 0 &&
                    (previousWidth in (widthOfTheField / 2) - 145..(widthOfTheField / 2) + 145) && edgeCheck
                ) {

                    Toast.makeText(this, "Blue scored a goal!", Toast.LENGTH_LONG).show()
                    counterBlue += 1

                    blueText.text = counterBlue.toString()

                    canvas3.drawColor(Color.rgb(153, 201, 0))
                    paintCourt(canvas, heightOfTheField, widthOfTheField, paint)
                    paintDots(canvasv2, heightOfTheField, widthOfTheField, paintv2)

                    currentHeight = 0
                    currentWidth = 0
                    previousHeight = heightOfTheField / 2
                    previousWidth = widthOfTheField / 2

                    paint3.color = Color.rgb(170, 35, 35)
                    canvas3.drawCircle(
                        previousWidth.toFloat(),
                        previousHeight.toFloat(),
                        8F,
                        paint3
                    )
                    was_red = true

                    check = false
                    edgeCheck = false
                    upCheck = false
                    downCheck = false
                    leftCheck = false
                    rightCheck = false
                    movePermission = false
                    wannaReset = 0
                    reset.isEnabled = false

                    previousHeightList.clear()
                    previousWidthList.clear()

                    imageView.setImageBitmap(bitmap)

                } else if (currentHeight - 545 >= heightOfTheField && currentHeight - 605 <= heightOfTheField &&
                    (previousWidth in (widthOfTheField / 2) - 145..(widthOfTheField / 2) + 145) && edgeCheck
                ) {

                    Toast.makeText(this, "Red scored a goal!", Toast.LENGTH_LONG).show()
                    counterRed += 1

                    redText.text = counterRed.toString()

                    canvas3.drawColor(Color.rgb(153, 201, 0))
                    paintCourt(canvas, heightOfTheField, widthOfTheField, paint)
                    paintDots(canvasv2, heightOfTheField, widthOfTheField, paintv2)

                    currentHeight = 0
                    currentWidth = 0
                    previousHeight = heightOfTheField / 2
                    previousWidth = widthOfTheField / 2

                    paint3.color = Color.rgb(82, 208, 208)
                    canvas3.drawCircle(
                        previousWidth.toFloat(),
                        previousHeight.toFloat(),
                        8F,
                        paint3
                    )
                    was_red = false

                    check = false
                    edgeCheck = false
                    upCheck = false
                    downCheck = false
                    leftCheck = false
                    rightCheck = false
                    movePermission = false
                    wannaReset = 0
                    reset.isEnabled = false

                    previousHeightList.clear()
                    previousWidthList.clear()

                    imageView.setImageBitmap(bitmap)

                }
                else if(!spotAlreadyTaken){

                 if (edgeCheck) {

                    if (rightCheck) {
                        //can only move left side

                        if ((diffHeight in 90..130 || diffHeight in -130..-90) &&
                            (diffWidth in -145..-100) || diffWidth in -145..-100 && (diffHeight in 0..15 || diffHeight in -15..0)
                        ) {

                            rightCheck = false
                            edgeCheck = false
                            movePermission = true

                        } else {

                            Toast.makeText(this, "You can't go there!", Toast.LENGTH_SHORT).show()
                            check = false
                            wannaReset += 1

                            if(wannaReset > 1){

                                reset.isEnabled = true

                            }

                        }

                    } else if (leftCheck) {
                        //can only go right

                        if ((diffHeight in 90..130 || diffHeight in -130..-90) &&
                            (diffWidth in 100..145) || diffWidth in 100..145 && (diffHeight in 0..15 || diffHeight in -15..0)
                        ) {

                            leftCheck = false
                            edgeCheck = false
                            movePermission = true

                        } else {

                            Toast.makeText(this, "You can't go there!", Toast.LENGTH_SHORT).show()
                            check = false
                            wannaReset += 1

                            if(wannaReset > 1){

                                reset.isEnabled = true

                            }

                        }


                    } else if (upCheck) {
                        //can only go down or score a goal
                        if ((diffHeight in 90..130) &&
                            (diffWidth in 100..145 || diffWidth in -145..-100) || (diffHeight in 90..130 && (diffWidth in 0..15 || diffWidth in -15..0)) ||
                            (diffHeight in -130..-90 && (diffWidth in 0..15 || diffWidth in -15..0) &&
                                    (previousWidth in (widthOfTheField / 2) - 145..(widthOfTheField / 2) + 145))
                        ) {

                            upCheck = false
                            edgeCheck = false
                            movePermission = true

                        } else {

                            Toast.makeText(this, "You can't go there!", Toast.LENGTH_SHORT).show()
                            check = false
                            wannaReset += 1

                            if(wannaReset > 1){

                                reset.isEnabled = true

                            }

                        }

                    } else if (downCheck) {

                        //can only go up or score a goal
                        if ((diffHeight in -130..-90) &&
                            (diffWidth in 100..145 || diffWidth in -145..-100) || (diffHeight in 90..130 && (diffWidth in 0..15 || diffWidth in -15..0) &&
                                    (previousWidth in (widthOfTheField / 2) - 145..(widthOfTheField / 2) + 145)) ||
                            (diffHeight in -130..-90 && (diffWidth in 0..15 || diffWidth in -15..0))
                        ) {

                            downCheck = false
                            edgeCheck = false
                            movePermission = true

                        } else {

                            Toast.makeText(this, "You can't go there!", Toast.LENGTH_SHORT).show()
                            check = false
                            wannaReset += 1

                            if(wannaReset > 1){

                                reset.isEnabled = true

                            }

                        }

                    }

                    if (movePermission) {

                        wannaReset = 0
                        reset.isEnabled = false

                        paint3.color = Color.rgb(100, 100, 100)
                        canvas3.drawCircle(
                            previousWidth.toFloat(),
                            previousHeight.toFloat(),
                            8F,
                            paint3
                        )
                        paint3.color = Color.rgb(0, 0, 0)
                        canvas3.drawLine(
                            previousWidth.toFloat(),
                            previousHeight.toFloat(),
                            currentWidth - 105.toFloat(),
                            currentHeight - 575.toFloat(),
                            paint3
                        )
                        previousHeightList.add(previousHeight/97)
                        previousWidthList.add(previousWidth/114)
                        previousWidth = currentWidth - 105
                        previousHeight = currentHeight - 575
                        imageView.setImageBitmap(bitmap)
                        check = false
                        movePermission = false

                        if (currentWidth - 95 >= widthOfTheField && currentWidth - 115 <= widthOfTheField) {
                            rightCheck = true
                            edgeCheck = true

                        } else if (currentWidth - 95 >= 0 && currentWidth - 115 <= 0) {
                            leftCheck = true
                            edgeCheck = true

                        } else if (currentHeight - 545 >= heightOfTheField - 122 && currentHeight - 605 <= heightOfTheField - 122) {
                            downCheck = true
                            edgeCheck = true

                        } else if (currentHeight - 545 >= 122 && currentHeight - 605 <= 122) {
                            upCheck = true
                            edgeCheck = true

                        }

                        if (edgeCheck) {

                            if (was_red) {

                                paint3.color = Color.rgb(170, 35, 35)
                                canvas3.drawCircle(
                                    previousWidth.toFloat(),
                                    previousHeight.toFloat(),
                                    8F,
                                    paint3
                                )

                            } else {

                                paint3.color = Color.rgb(82, 208, 208)
                                canvas3.drawCircle(
                                    previousWidth.toFloat(),
                                    previousHeight.toFloat(),
                                    8F,
                                    paint3
                                )

                            }

                        } else {

                            if (was_red) {

                                paint3.color = Color.rgb(82, 208, 208)
                                canvas3.drawCircle(
                                    previousWidth.toFloat(),
                                    previousHeight.toFloat(),
                                    8F,
                                    paint3
                                )
                                was_red = false

                            } else {

                                paint3.color = Color.rgb(170, 35, 35)
                                canvas3.drawCircle(
                                    previousWidth.toFloat(),
                                    previousHeight.toFloat(),
                                    8F,
                                    paint3
                                )
                                was_red = true

                            }

                        }
                    }

                } else if (((diffHeight in 90..130 || diffHeight in -130..-90) &&
                            (diffWidth in 100..145 || diffWidth in -145..-100)) ||
                    (diffWidth in 100..145 || diffWidth in -145..-100) &&
                    (diffHeight in 0..15 || diffHeight in -15..0) ||
                    (diffHeight in 90..130 || diffHeight in -130..-90) &&
                    (diffWidth in 0..15 || diffWidth in -15..0)
                ) {
                     wannaReset = 0
                     reset.isEnabled = false
                    paint3.color = Color.rgb(100, 100, 100)
                    canvas3.drawCircle(
                        previousWidth.toFloat(),
                        previousHeight.toFloat(),
                        8F,
                        paint3
                    )
                    paint3.color = Color.rgb(0, 0, 0)
                    canvas3.drawLine(
                        previousWidth.toFloat(),
                        previousHeight.toFloat(),
                        currentWidth - 105.toFloat(),
                        currentHeight - 575.toFloat(),
                        paint3
                    )
                     previousHeightList.add(previousHeight/97)
                     previousWidthList.add(previousWidth/114)
                    previousWidth = currentWidth - 105
                    previousHeight = currentHeight - 575
                    imageView.setImageBitmap(bitmap)
                    check = false
                    if (currentWidth - 95 >= widthOfTheField && currentWidth - 115 <= widthOfTheField) {
                        rightCheck = true
                        edgeCheck = true

                    } else if (currentWidth - 95 >= 0 && currentWidth - 115 <= 0) {
                        leftCheck = true
                        edgeCheck = true

                    } else if (currentHeight - 545 >= heightOfTheField - 122 && currentHeight - 605 <= heightOfTheField - 122) {
                        downCheck = true
                        edgeCheck = true

                    } else if (currentHeight - 545 >= 122 && currentHeight - 605 <= 122) {
                        upCheck = true
                        edgeCheck = true

                    }

                    if (edgeCheck) {

                        if (was_red) {

                            paint3.color = Color.rgb(170, 35, 35)
                            canvas3.drawCircle(
                                previousWidth.toFloat(),
                                previousHeight.toFloat(),
                                8F,
                                paint3
                            )

                        } else {

                            paint3.color = Color.rgb(82, 208, 208)
                            canvas3.drawCircle(
                                previousWidth.toFloat(),
                                previousHeight.toFloat(),
                                8F,
                                paint3
                            )

                        }

                    } else {

                        if (was_red) {

                            paint3.color = Color.rgb(82, 208, 208)
                            canvas3.drawCircle(
                                previousWidth.toFloat(),
                                previousHeight.toFloat(),
                                8F,
                                paint3
                            )
                            was_red = false

                        } else {

                            paint3.color = Color.rgb(170, 35, 35)
                            canvas3.drawCircle(
                                previousWidth.toFloat(),
                                previousHeight.toFloat(),
                                8F,
                                paint3
                            )
                            was_red = true

                        }

                    }


                } else {

                    Toast.makeText(this, "You can't go there!", Toast.LENGTH_SHORT).show()
                     wannaReset += 1
                    check = false

                     if(wannaReset > 1){

                         reset.isEnabled = true

                     }

                }

            }
                else{

                    Toast.makeText(this, "Spot already taken!", Toast.LENGTH_SHORT).show()
                    check = false
                    spotAlreadyTaken = false
                    wannaReset += 1

                    if(wannaReset > 1){

                        reset.isEnabled = true

                    }

                }
            }

            mHandler.postDelayed(
                mRunnable,
                10
            )

        }

        mHandler.postDelayed(
            mRunnable,
            10
        )

        imageView.setImageBitmap(bitmap)

        quit.setOnClickListener {
            mHandler.removeCallbacks(mRunnable);
            mHandler = Handler()
            finish()

        }

        reset.setOnClickListener{

            if(was_red){

                Toast.makeText(this, "Red was stuck!", Toast.LENGTH_LONG).show()
                counterRed -= 1

                redText.text = counterRed.toString()

                canvas3.drawColor(Color.rgb(153, 201, 0))
                paintCourt(canvas, heightOfTheField, widthOfTheField, paint)
                paintDots(canvasv2, heightOfTheField, widthOfTheField, paintv2)

                currentHeight = 0
                currentWidth = 0
                previousHeight = heightOfTheField / 2
                previousWidth = widthOfTheField / 2

                paint3.color = Color.rgb(170, 35, 35)
                canvas3.drawCircle(
                    previousWidth.toFloat(),
                    previousHeight.toFloat(),
                    8F,
                    paint3
                )
                was_red = true

                check = false
                edgeCheck = false
                upCheck = false
                downCheck = false
                leftCheck = false
                rightCheck = false
                movePermission = false
                wannaReset = 0
                reset.isEnabled = false

                previousHeightList.clear()
                previousWidthList.clear()

                imageView.setImageBitmap(bitmap)

            }

            else{

                Toast.makeText(this, "Blue was stuck!", Toast.LENGTH_LONG).show()
                counterBlue -= 1

                blueText.text = counterBlue.toString()

                canvas3.drawColor(Color.rgb(153, 201, 0))
                paintCourt(canvas, heightOfTheField, widthOfTheField, paint)
                paintDots(canvasv2, heightOfTheField, widthOfTheField, paintv2)

                currentHeight = 0
                currentWidth = 0
                previousHeight = heightOfTheField / 2
                previousWidth = widthOfTheField / 2

                paint3.color = Color.rgb(82, 208, 208)
                canvas3.drawCircle(
                    previousWidth.toFloat(),
                    previousHeight.toFloat(),
                    8F,
                    paint3
                )
                was_red = false

                check = false
                edgeCheck = false
                upCheck = false
                downCheck = false
                leftCheck = false
                rightCheck = false
                movePermission = false
                wannaReset = 0
                reset.isEnabled = false

                previousHeightList.clear()
                previousWidthList.clear()

                imageView.setImageBitmap(bitmap)


            }

        }

    }

    private fun paintDots(canvas : Canvas, height: Int, width: Int, paint : Paint) {

        val radius = 8F
        var counter : Int = 0
        var secondHalf : Boolean = false

        for(i in height downTo 0 step 106){
            counter =0
            for(j in width downTo 0 step 122){
                if((i == height || i<106)&&counter <4){

                    counter+= 1

                }
                else if((i == height || i<106)) {

                    if (counter <7){

                        canvas.drawCircle(width - j.toFloat(), height - i.toFloat(), radius, paint)
                        counter += 1

                    }

                    else{

                        counter = 0

                    }
                }

                else{

                    canvas.drawCircle(width - j.toFloat(), height - i.toFloat(), radius, paint)

                }


                }

            }

        }

    private fun paintCourt(canvas : Canvas, height : Int, width: Int, paint : Paint) {
        //middle
        canvas.drawLine(
            0.toFloat(), height/2.toFloat(), width.toFloat(), height/2.toFloat(), paint)
        //left
        canvas.drawLine(
            5.toFloat(), 100.toFloat(), 5.toFloat(), height-100.toFloat(), paint)
        //right
        canvas.drawLine(
            width-5.toFloat(), 100.toFloat(), width-5.toFloat(), height-100.toFloat(), paint)
        //upper right
        canvas.drawLine(
            width.toFloat(), 100.toFloat(), width*5/8.toFloat(), 100.toFloat(), paint)
        //upper left
        canvas.drawLine(
            0.toFloat(), 100.toFloat(), width*3/8.toFloat(), 100.toFloat(), paint)

        //lower right
        canvas.drawLine(
            width.toFloat(), height-100.toFloat(), width*5/8.toFloat(), height-100.toFloat(), paint)

        //lower left
        canvas.drawLine(
            0.toFloat(), height-100.toFloat(), width*3/8.toFloat(), height-100.toFloat(), paint)

        //upper right gate
        paint.color = Color.rgb(170,35,35)
        canvas.drawLine(
            width*5/8.toFloat(), 110.toFloat(), width*5/8.toFloat(), 0.toFloat(), paint)

        //upper left gate
        canvas.drawLine(
            width*3/8.toFloat(), 110.toFloat(), width*3/8.toFloat(), 0.toFloat(), paint)

        //lower right gate
        paint.color = Color.rgb(82,208,208)
        canvas.drawLine(
            width*5/8.toFloat(), height-110.toFloat(), width*5/8.toFloat(), height.toFloat(), paint)

        //lower right gate
        canvas.drawLine(
            width*3/8.toFloat(), height-110.toFloat(), width*3/8.toFloat(), height.toFloat(), paint)

        paint.color = Color.rgb(215,224,210)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                currentWidth = event.x.toInt()
                currentHeight = event.y.toInt()
                check = true
                //Toast.makeText(this, currentHeight.toString(), Toast.LENGTH_LONG).show()
            }
        }
        return false
    }

}
