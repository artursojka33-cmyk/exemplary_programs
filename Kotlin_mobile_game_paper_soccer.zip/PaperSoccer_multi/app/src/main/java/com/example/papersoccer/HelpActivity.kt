package com.example.papersoccer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class HelpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        val prev_button = findViewById<Button>(R.id.previousButton)
        val next_button = findViewById<Button>(R.id.nextButton)
        val back_button = findViewById<Button>(R.id.back_Button)
        val currentImage = findViewById<ImageView>(R.id.helpImage)
        val currentText = findViewById<TextView>(R.id.helpText)
        var counter : Int = 0

        prev_button.isEnabled = false

        currentText.text = getString(R.string.help_text_1)
        currentImage.setImageResource(0)
        currentImage.setImageResource(R.drawable.help_1)

        prev_button.setOnClickListener{

            //go to the previous picture

            if(counter == 1){

                counter -= 1
                prev_button.isEnabled = false

                currentImage.setImageResource(R.drawable.help_1)
                currentText.text = getString(R.string.help_text_1)

            }
            else  if(counter == 2){
                counter-=1
                currentImage.setImageResource(R.drawable.help_2)
                currentText.text = getString(R.string.help_text_2)

            }
            else if(counter == 3){

                counter-=1
                currentImage.setImageResource(R.drawable.help_3)
                currentText.text = getString(R.string.help_text_3)

            }
            else if(counter ==4){

                counter-=1
                currentImage.setImageResource(R.drawable.help_4)
                currentText.text = getString(R.string.help_text_4)

            }
            else if(counter == 5){

                counter -= 1
                currentImage.setImageResource(R.drawable.hepl_5)
                currentText.text = getString(R.string.help_text_5)

            }
            else if(counter == 6){

                counter -= 1
                currentImage.setImageResource(R.drawable.help_6)
                currentText.text = getString(R.string.help_text_6)
                next_button.isEnabled = true
            }


        }

        next_button.setOnClickListener {

            //go to the next picture

            if(counter == 0){

                counter+=1
                currentImage.setImageResource(R.drawable.help_2)
                currentText.text = getString(R.string.help_text_2)
                prev_button.isEnabled = true

            }

            else if(counter==1){

                counter+=1
                currentImage.setImageResource(R.drawable.help_3)
                currentText.text = getString(R.string.help_text_3)

            }

            else  if(counter == 2){

                counter+=1
                currentImage.setImageResource(R.drawable.help_4)
                currentText.text = getString(R.string.help_text_4)

            }
            else if(counter == 3){

                counter+=1
                currentImage.setImageResource(R.drawable.hepl_5)
                currentText.text = getString(R.string.help_text_5)

            }
            else if(counter ==4){

                counter+=1
                currentImage.setImageResource(R.drawable.help_6)
                currentText.text = getString(R.string.help_text_6)

            }
            else if(counter == 5){

                next_button.isEnabled = false
                counter += 1
                currentImage.setImageResource(R.drawable.hepl_7)
                currentText.text = getString(R.string.help_text_7)

            }

        }

        back_button.setOnClickListener{

            finish()
            //currentImage.setImageResource(0)
        }

    }
}