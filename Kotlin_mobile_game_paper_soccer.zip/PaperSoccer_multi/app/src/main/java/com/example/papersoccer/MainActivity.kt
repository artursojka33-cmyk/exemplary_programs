package com.example.papersoccer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val start_button = findViewById<Button>(R.id.startButton)
        val help_button = findViewById<Button>(R.id.helpButton)
        val options_button = findViewById<Button>(R.id.back_Button)


        start_button.setOnClickListener{

            val intent: Intent = Intent(this, StartActivity::class.java)
            startActivity(intent)

        }

        help_button.setOnClickListener{

            val intent: Intent = Intent(this, HelpActivity::class.java)
            startActivity(intent)

        }

        options_button.setOnClickListener{

            val intent: Intent = Intent(this, SettingsActivity::class.java)
            //intent.putExtra --> get switch
            //intent.putExtra --> get switch2
            startActivity(intent)

        }
    }
}
