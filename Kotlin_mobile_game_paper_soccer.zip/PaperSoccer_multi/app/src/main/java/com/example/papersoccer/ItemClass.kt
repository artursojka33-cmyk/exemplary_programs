package com.example.papersoccer

data class ItemClass(val imageResource: Int, var text1: String, var text2: String)